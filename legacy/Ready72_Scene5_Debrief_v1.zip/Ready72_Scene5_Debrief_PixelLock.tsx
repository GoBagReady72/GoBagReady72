import React from "react";

export default function Ready72_Scene5_Debrief_PixelLock(): JSX.Element {
  return (
    <div className="min-h-screen bg-[#0B1220] text-slate-100">
      <div className="max-w-[1200px] mx-auto px-6 pt-6">
        {/* Tabs */}
        <div className="flex items-center gap-2 mb-4 text-sm">
          {[
            { t: "Intro", a: false },
            { t: "Persona", a: false },
            { t: "Briefing", a: false },
            { t: "Store", a: false },
            { t: "Decision", a: false },
            { t: "Debrief", a: true },
          ].map(({ t, a }) => (
            <span key={t} className={"px-3 py-1 rounded-full border " + (a ? "bg-orange-500 text-white border-orange-500" : "border-slate-600 text-slate-300")}>{t}</span>
          ))}
        </div>

        {/* Header */}
        <div className="flex items-end justify-between border-b border-slate-700 pb-3 mb-4">
          <div className="text-sm"><span className="text-orange-400 font-semibold">GoBag:</span> <span className="font-semibold">Ready72</span></div>
          <div className="text-xs text-slate-300">Scene 5 · Debrief</div>
        </div>

        <div className="grid gap-6 items-start" style={{ gridTemplateColumns: '1.65fr 1fr' }}>
          {/* Left: MSS report card */}
          <section className="bg-[#0F172A]/70 rounded-2xl border border-slate-700 p-5">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-bold">MSS Report Card</h2>
              <span className="text-[12px] px-3 py-1 rounded-full bg-slate-800 border border-slate-700 text-slate-200">Outcome: LOSS</span>
            </div>
            <div className="h-1.5 w-full rounded-full bg-slate-700 mb-4 overflow-hidden">
              <div className="h-full w-[5%] bg-green-500" />
            </div>

            <div className="grid grid-cols-2 gap-5">
              {[
                {label: 'Water', val: 0},{label: 'Food', val: 0},
                {label: 'Shelter', val: 0},{label: 'Health & PPE', val: 0},
                {label: 'Comms & Nav', val: 0},{label: 'Sustainability', val: 0},
                {label: 'Special', val: 0, full: true},
              ].map((m, i) => (
                <div key={i} className={m.full? 'col-span-2' : ''}>
                  <div className="text-sm text-slate-200 mb-1 flex items-center justify-between">
                    <span>{m.label}</span>
                    <span className="text-slate-400 text-xs">{m.val}%</span>
                  </div>
                  <div className="h-2 rounded-full bg-slate-800 border border-slate-700 overflow-hidden">
                    <div className="h-full bg-orange-500" style={{width: `${m.val}%`}} />
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-4 mt-5 p-3 border border-slate-700 rounded-xl">
              <div className="text-sm"><span className="font-semibold">FRS Outcome:</span> <span className="text-rose-300 font-semibold">At risk</span><div className="text-slate-400 text-xs">Average MSS alignment: 0%</div></div>
              <div className="ml-auto">
                <button className="px-3 py-1.5 rounded-md border border-slate-700 text-slate-200 hover:bg-slate-800 text-xs">Complete Ready72 again</button>
              </div>
            </div>

            <div className="mt-5 border border-slate-700 rounded-2xl p-4">
              <div className="font-semibold mb-2">Reflection</div>
              <ul className="list-disc pl-6 space-y-1 text-sm text-slate-200">
                <li>What would you change before the next scenario?</li>
                <li>Which category fell below 60%? Focus there first.</li>
                <li>Could you reduce weight without losing balance?</li>
              </ul>
              <div className="mt-5 flex items-center justify-between">
                <button className="px-3 py-2 rounded-md border border-slate-700 text-slate-200 hover:bg-slate-800">Play again</button>
                <button className="px-4 py-2 rounded-md bg-orange-500 hover:bg-orange-600 text-white font-semibold">Open HazAssist Dashboard →</button>
              </div>
            </div>
          </section>

          {/* Right: HazAssist + Key Events */}
          <div className="space-y-6">
            <section className="bg-[#0F172A]/70 rounded-2xl border border-slate-700 p-5">
              <div className="text-[11px] tracking-wider text-slate-300 font-semibold mb-3">HAZASSIST · SYSTEM ADVISOR</div>
              <div className="space-y-3">
                {["This summary shows how balanced your kit was by category.", "Try to reach 60% or higher in each category to improve outcomes.", "In HazAssist, this connects to your real readiness plan."].map((line, i) => (
                  <div key={i} className="rounded-lg border border-slate-700/70 px-4 py-3 text-sm">{line}</div>
                ))}
              </div>
            </section>

            <section className="bg-[#0F172A]/70 rounded-2xl border border-slate-700 p-5">
              <div className="font-semibold text-sm mb-2">Key Events</div>
              <div className="h-24 rounded-lg border border-slate-700/70 text-slate-400 text-sm flex items-center justify-center">(placeholder)</div>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}