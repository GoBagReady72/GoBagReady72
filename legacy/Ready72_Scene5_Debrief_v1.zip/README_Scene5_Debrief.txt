Ready72 — Scene 5 · Debrief (Baseline Wireframe Spec)
=================================================
ExportTag: #R72-BWS-Scene5-Debrief-v1

Purpose
- Static debrief baseline with MSS Report Card, HazAssist summary, reflection, and next-step CTA.

Files
- Ready72_Scene5_Debrief_PixelLock.tsx (canonical TSX; static UI)
- 5_Debrief.png (reference screenshot)

Layout Notes
- Continues Scene 0–4 visual hierarchy (tabs, header, color palette)
- Two main panels: Report Card (left) and HazAssist/Key Events (right)
- Reflection area includes replay and HazAssist dashboard buttons
- Designed for static baseline preview; no interactivity yet

Preview
- Import and render the TSX to confirm alignment and proportions visually.
