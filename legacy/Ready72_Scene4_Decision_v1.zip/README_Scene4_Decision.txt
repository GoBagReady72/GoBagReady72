Ready72 — Scene 4 · Decision (Baseline Wireframe Spec)
=================================================
ExportTag: #R72-BWS-Scene4-Decision-v1

Purpose
- Static decision loop baseline with HazAssist advisor, 3×2 action grid,
  route map placeholder, and five aligned status meters.

Files
- Ready72_Scene4_Decision_PixelLock.tsx (canonical TSX; static UI)
- 4_Decision.png (reference screenshot)

Layout Notes
- Same chrome as Scenes 0–3 (tabs, header, status strip)
- Action buttons in two rows of three
- Status meters: two-line labels (category, percent), baseline-aligned bars
- Right column: Event Log with Force End + Finish & Debrief

Preview
- Import and render the TSX to verify layout visually.
