import React from "react";

export default function Ready72_Scene4_Decision_PixelLock(): JSX.Element {
  return (
    <div className="min-h-screen bg-[#0B1220] text-slate-100">
      <div className="max-w-[1200px] mx-auto px-6 pt-6">
        {/* Tabs */}
        <div className="flex items-center gap-2 mb-4 text-sm">
          {[
            { t: "Intro", a: false },
            { t: "Persona", a: false },
            { t: "Briefing", a: false },
            { t: "Store", a: false },
            { t: "Decision", a: true },
          ].map(({ t, a }) => (
            <span key={t} className={"px-3 py-1 rounded-full border " + (a ? "bg-orange-500 text-white border-orange-500" : "border-slate-600 text-slate-300")}>{t}</span>
          ))}
        </div>

        {/* Header */}
        <div className="flex items-end justify-between border-b border-slate-700 pb-3 mb-4">
          <div className="text-sm"><span className="text-orange-400 font-semibold">GoBag:</span> <span className="font-semibold">Ready72</span></div>
          <div className="text-xs text-slate-300">Scene 4 · Decision Loop (4-hour cycle)</div>
        </div>

        {/* Status strip */}
        <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm mb-6">
          <div className="bg-[#0F172A]/70 border border-slate-700 rounded-full px-3 py-1">Profile: <span className="font-semibold">Everyday Civilian</span></div>
          <div className="flex items-center gap-2 bg-[#0F172A]/70 border border-slate-700 rounded-full px-3 py-1">
            <span className="text-slate-300">Seed:</span>
            <input defaultValue={42} className="w-14 text-center bg-slate-900/60 border border-slate-700 rounded-sm text-slate-200 text-sm py-0.5" />
          </div>
          <div className="ml-auto flex items-center gap-4">
            <div className="text-slate-300">Time remaining: <span className="text-slate-100 font-semibold">12 h</span></div>
            <div className="text-slate-300">Distance to safety: <span className="text-slate-100 font-semibold">30 km</span></div>
            <div className="text-slate-300">Encumbrance ratio: <span className="text-slate-100 font-semibold">0.00×</span></div>
          </div>
        </div>

        {/* Three columns: Advisor | Action/Map | Log */}
        <div className="grid gap-6 items-stretch" style={{ gridTemplateColumns: '1.05fr 1.35fr 0.9fr' }}>
          {/* Advisor */}
          <section className="bg-[#0F172A]/70 rounded-2xl border border-slate-700 p-4 self-start">
            <div className="text-[11px] tracking-wider text-slate-300 font-semibold mb-3">HAZASSIST · SYSTEM ADVISOR</div>
            <div className="space-y-3">
              {["Pick your next move. Each choice changes speed, water, food, and morale.", "Overweight packs reduce your speed and increase fatigue.", "A radio or water filter can turn setbacks into neutral events."].map((line, i) => (
                <div key={i} className="rounded-lg border border-slate-700/70 px-4 py-3 bg-transparent text-slate-100 text-sm">{line}</div>
              ))}
            </div>
          </section>

          {/* Choose action + map */}
          <section className="bg-[#0F172A]/70 rounded-2xl border border-slate-700 p-5 flex flex-col">
            <div className="text-[11px] tracking-wider text-slate-300 font-semibold mb-3">CHOOSE AN ACTION</div>
            <div className="grid grid-cols-3 gap-2 mb-3">
              {["Move — Easy", "Move — Normal", "Move — Fast", "Rest", "Ration", "Divert Route"].map((label, i) => (
                <button key={i} className="h-10 rounded-md border border-slate-700 text-slate-200 hover:bg-slate-800 font-semibold text-sm">{label}</button>
              ))}
            </div>

            <div className="flex-1 rounded-xl border border-slate-700/70 bg-transparent flex items-center justify-center text-slate-400 text-sm mb-3 min-h-[240px]">Route map placeholder</div>

            {/* Status meters */}
            <div className="grid grid-cols-5 gap-4 text-[12px] items-end">
              {[
                {label: 'Hydration', val: 60},
                {label: 'Calories', val: 60},
                {label: 'Morale', val: 60},
                {label: 'MSS alignment', val: 50},
                {label: 'Pack weight (limit %)', val: 0},
              ].map((m,i)=> (
                <div key={i} className="flex flex-col w-full h-16 justify-end">
                  <div className="text-center text-slate-300 leading-tight">
                    <div>{m.label}:</div>
                    <div className="text-slate-400">{m.val}%</div>
                  </div>
                  <div className="h-2 rounded-full overflow-hidden border border-slate-700 mt-1">
                    <div className="h-full bg-orange-500" style={{ width: `${m.val}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Event log */}
          <section className="bg-[#0F172A]/70 rounded-2xl border border-slate-700 p-5 flex flex-col">
            <div className="text-[11px] tracking-wider text-slate-300 font-semibold mb-3">EVENT LOG</div>
            <div className="flex-1 rounded-lg border border-slate-700/70 p-3 text-sm space-y-2 overflow-auto">
              <div className="text-slate-100">KOE: Flood Watch — Reach high ground before the surge (demo).</div>
            </div>
            <div className="pt-3 flex gap-2 justify-end">
              <button className="h-9 px-3 rounded-md border border-slate-600 text-slate-200 hover:bg-slate-800">Force End</button>
              <button className="h-9 px-3 rounded-md bg-orange-500 hover:bg-orange-600 text-white font-semibold">Finish & Debrief</button>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
